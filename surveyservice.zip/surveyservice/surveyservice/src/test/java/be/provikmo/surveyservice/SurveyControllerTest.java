package be.provikmo.surveyservice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import be.provikmo.surveyservice.SurveyController;
import be.provikmo.surveyservice.SurveyService;

@RunWith(SpringRunner.class)
@WebMvcTest(SurveyController.class)
public class SurveyControllerTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private SurveyService surveyService;

	@Test
	public void afterSurveyComplete200() throws Exception {
		this.mvc.perform(post("/afterSurveyComplete").content("{\"surveyId\":\"12345\"}"))
			.andExpect(status().is2xxSuccessful());
	}

	@Test
	public void afterSurveyComplete500() throws Exception {
		this.mvc.perform(post("/afterSurveyComplete").content("{}")).andExpect(status().is5xxServerError());
	}

}
