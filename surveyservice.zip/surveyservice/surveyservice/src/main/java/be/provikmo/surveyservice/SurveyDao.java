package be.provikmo.surveyservice;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class SurveyDao {

	private static final String SURVEY_EXISTS = "select count(*) from md_vragenlijst where survey = ?";

	private JdbcTemplate jdbcTemplate;

	public SurveyDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean surveyExists(String surveyId) {
		return jdbcTemplate.queryForObject(SURVEY_EXISTS, Integer.class, surveyId) == 1;
	}

}
