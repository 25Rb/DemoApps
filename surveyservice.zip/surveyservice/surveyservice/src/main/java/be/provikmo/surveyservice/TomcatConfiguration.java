package be.provikmo.surveyservice;

import org.apache.catalina.connector.Connector;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("!local")
public class TomcatConfiguration {

	@Value(value = "${provikmo.server.tomcat.ajpPort}")
	private int ajpPort;

	@Bean
	public EmbeddedServletContainerFactory servletContainer() {
		TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();
		tomcat.addAdditionalTomcatConnectors(createConnector());
		return tomcat;
	}

	private Connector createConnector() {
		Connector connector = new Connector("AJP/1.3");
		connector.setPort(ajpPort);
		return connector;
	}

}
