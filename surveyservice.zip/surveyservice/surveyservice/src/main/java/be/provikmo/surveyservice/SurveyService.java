package be.provikmo.surveyservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class SurveyService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SurveyService.class);

	@Value("${survey.emb.queue}")
	private String queueName;

	private JmsTemplate jmsTemplate;

	private SurveyDao surveyDao;

	public SurveyService(JmsTemplate jmsTemplate, SurveyDao surveyDao) {
		this.jmsTemplate = jmsTemplate;
		this.surveyDao = surveyDao;
	}

	public void afterSurveyComplete(final String surveyId, final String message) {
		if (surveyDao.surveyExists(surveyId)) {
			LOGGER.info("Sending message for survey with id '{}'", surveyId);
			jmsTemplate.send(queueName, session -> session.createTextMessage(message));
		} else {
			LOGGER.error("Survey with id '{}' does not exist", surveyId);
		}
	}

}
